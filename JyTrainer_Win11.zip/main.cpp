#include "game_process.h"
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef _WINSOCKAPI_
#define _WINSOCKAPI_
#endif

#include <windows.h>
#include <d3d9.h>
#include <stdio.h>
#include <cstdarg>
#include <clocale>

#include "memory_reader.h"
#include "bot_logic.h"
#include "gui_ranbot.h"
#include "offset_config.h"
#include "input_sender.h"
#include "resource.h"

// ImGui
#include "imgui/imgui.h"
#include "imgui/imgui_impl_dx9.h"
#include "imgui/imgui_impl_win32.h"

// 連結 DirectX9 庫（因為無法修改 vcxproj）
#ifdef _MSC_VER
#pragma comment(lib, "d3d9.lib")
#endif

// 全局熱鍵 ID（定義在 gui_ranbot.h，保持一致）

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

// 從 gui_ranbot.cpp 引入的變量（供 WM_HOTKEY 使用）
extern volatile long s_captureMode;
extern volatile long s_captureFieldId;
extern HHOOK s_hMouseHookCapture;
extern LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam);

static void Dbg(const char* msg);
static void Dbgf(const char* fmt, ...);
void CleanupGameProcess();
extern void ShutdownHotkeys();

// ============================================================
// 窗口尺寸常量
// ============================================================
static const int WINDOW_WIDTH = 620;
static const int WINDOW_HEIGHT = 720;

// ============================================================
// DirectX9 全局變量
// ============================================================
static LPDIRECT3D9              g_pD3D = nullptr;
static LPDIRECT3DDEVICE9        g_pd3dDevice = nullptr;
static D3DPRESENT_PARAMETERS    g_d3dpp = {};
HWND                            g_hWnd = nullptr;  // 非 static，供其他模組使用
static bool                     g_imguiReady = false;

// ============================================================
// GUI 全局變量
// ============================================================
bool g_guiVisible = true;             // GUI 是否可見
bool g_alwaysOnTop = false;           // 是否置頂（默認關閉，不擋遊戲）

// ============================================================
// 單一實例保護
// ============================================================
static HANDLE s_hSingleInstanceMutex = NULL;
static bool AcquireSingleInstance() {
    s_hSingleInstanceMutex = CreateMutexW(NULL, TRUE, L"JyTrainer_SingleInstance_Mutex");
    if (!s_hSingleInstanceMutex) return false;
    if (GetLastError() == ERROR_ALREADY_EXISTS) {
        CloseHandle(s_hSingleInstanceMutex);
        s_hSingleInstanceMutex = NULL;
        return false;
    }
    return true;
}
static void ReleaseSingleInstance() {
    if (s_hSingleInstanceMutex) {
        ReleaseMutex(s_hSingleInstanceMutex);
        CloseHandle(s_hSingleInstanceMutex);
        s_hSingleInstanceMutex = NULL;
    }
}

// ============================================================
// 創建 D3D 設備
// ============================================================
static bool CreateDeviceD3D(HWND hWnd) {
    if ((g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)) == nullptr)
        return false;

    ZeroMemory(&g_d3dpp, sizeof(g_d3dpp));

    // 🐛 修復 #1: 正確初始化 BackBuffer 尺寸
    RECT rect;
    GetClientRect(hWnd, &rect);
    int width = rect.right - rect.left;
    int height = rect.bottom - rect.top;

    // 確保最小尺寸
    if (width < 100) width = WINDOW_WIDTH;
    if (height < 100) height = WINDOW_HEIGHT;

    g_d3dpp.BackBufferWidth = width;
    g_d3dpp.BackBufferHeight = height;
    g_d3dpp.Windowed = TRUE;
    g_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
    g_d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
    g_d3dpp.EnableAutoDepthStencil = TRUE;
    // 🐛 修復 #2: 使用更兼容的深度缓冲格式
    g_d3dpp.AutoDepthStencilFormat = D3DFMT_D24X8;  // 比 D3DFMT_D16 更兼容
    g_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

    if (g_pD3D->CreateDevice(D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
        D3DCREATE_HARDWARE_VERTEXPROCESSING, &g_d3dpp, &g_pd3dDevice) < 0)
        return false;

    // ✅ 確保設備視口與窗口完全一致
    D3DVIEWPORT9 vp;
    vp.X = 0;
    vp.Y = 0;
    vp.Width = width;
    vp.Height = height;
    vp.MinZ = 0.0f;
    vp.MaxZ = 1.0f;
    g_pd3dDevice->SetViewport(&vp);

    return true;
}

// ============================================================
// 清理 D3D 設備
// ============================================================
static void CleanupDeviceD3D() {
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
    if (g_pD3D) { g_pD3D->Release(); g_pD3D = nullptr; }
}

// ============================================================
// Bot 執行緒 handle（需全域儲存以在關閉時正確清理）
// ============================================================
static HANDLE s_hBotThread = NULL;
static volatile LONG s_shutdownRequested = 0;

static void RequestAppShutdown(HWND hWnd, const char* reason) {
    if (InterlockedExchange(&s_shutdownRequested, 1) == 0) {
        Dbgf("[Shutdown] requested: %s", reason ? reason : "unknown");
    }
    g_Running = false;
    g_guiVisible = false;
    if (hWnd && IsWindow(hWnd)) {
        DestroyWindow(hWnd);
    } else {
        PostQuitMessage(0);
    }
}

// ============================================================
// 窗口處理函數
// ============================================================
#define WM_COORDCAPTURE (WM_USER + 100)
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return TRUE;

    switch (msg) {
    case WM_NCHITTEST: {
        const LRESULT hit = DefWindowProc(hWnd, msg, wParam, lParam);
        if (hit == HTCLIENT) {
            POINT pt = { LOWORD(lParam), HIWORD(lParam) };
            ScreenToClient(hWnd, &pt);
            RECT rc;
            GetClientRect(hWnd, &rc);
            const bool onHeaderButtons = pt.x >= (rc.right - 78) && pt.y >= 0 && pt.y < 48;
            if (pt.y >= 0 && pt.y < 48 && !onHeaderButtons)
                return HTCAPTION;
        }
        return hit;
    }

    case WM_GETMINMAXINFO: {
        MINMAXINFO* mmi = (MINMAXINFO*)lParam;
        mmi->ptMinTrackSize.x = WINDOW_WIDTH;
        mmi->ptMinTrackSize.y = WINDOW_HEIGHT;
        return 0;
    }

    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;

        if (g_pd3dDevice != nullptr) {
            int width = LOWORD(lParam);
            int height = HIWORD(lParam);

            if (width > 0 && height > 0) {
                g_d3dpp.BackBufferWidth = width;
                g_d3dpp.BackBufferHeight = height;
                if (g_imguiReady) {
                    ImGui_ImplDX9_InvalidateDeviceObjects();
                }

                HRESULT hr = g_pd3dDevice->Reset(&g_d3dpp);
                if (hr == D3D_OK) {
                    if (g_imguiReady) {
                        ImGui_ImplDX9_CreateDeviceObjects();
                    }
                } else {
                    printf("[警告] Device Reset 失敗: 0x%08lX\n", (unsigned long)hr);
                }
            }
        }
        return 0;

    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;

    case WM_CLOSE:
        RequestAppShutdown(hWnd, "WM_CLOSE");
        return 0;

    // ═══════════════ F9 量尺座標路由 ═══════════════
    // wParam = fieldId, lParam = MAKELPARAM(x, y)
    // 路由給 gui_ranbot.cpp 的 RenderMainGUI 處理
    case WM_COORDCAPTURE: {
        extern void RouteCapturedCoord(int fieldId, int x, int y);
        RouteCapturedCoord((int)wParam, (int)LOWORD(lParam), (int)HIWORD(lParam));
        return 0;
    }

    // ═══════════════ 全局熱鍵處理 (RegisterHotKey) ═══════════════
    case WM_HOTKEY: {
        int hotkeyId = (int)wParam;
        switch (hotkeyId) {
        case HOTKEY_F9: {
            // F9: 進入 / 取消量尺座標抓取模式
            extern volatile long s_captureMode;
            extern volatile long s_captureFieldId;
            extern HHOOK s_hMouseHookCapture;
            if (InterlockedCompareExchange(&s_captureMode, 0, 0) != 0) {
                // 已在抓取模式 → 取消
                InterlockedExchange(&s_captureMode, 0);
                InterlockedExchange(&s_captureFieldId, 0);
                if (s_hMouseHookCapture) {
                    UnhookWindowsHookEx(s_hMouseHookCapture);
                    s_hMouseHookCapture = NULL;
                }
                UIAddLog("[量尺] 已取消抓取模式");
            } else {
                // 進入抓取模式（fieldId 由 GUI 點擊設置）
                extern LRESULT CALLBACK LowLevelMouseProc(int nCode, WPARAM wParam, LPARAM lParam);
                s_hMouseHookCapture = SetWindowsHookEx(WH_MOUSE_LL, LowLevelMouseProc, GetModuleHandle(NULL), 0);
                if (s_hMouseHookCapture) {
                    InterlockedExchange(&s_captureMode, 1);
                    UIAddLog("[量尺] 按下 F9，請點擊遊戲視窗上的目標位置");
                } else {
                    UIAddLog("[量尺] 錯誤：無法安裝滑鼠鉤子");
                }
            }
            return 0;
        }
        // 注意：F10/F11/F12 由鍵盤鉤子 LowLevelKeyboardProc 處理（gui_ranbot.cpp）
        // 此處不處理，避免重複
        }
        break;
    }

    case WM_DESTROY:
        g_Running = false;
        g_guiVisible = false;
        g_hWnd = NULL;  // 標記窗口已銷毀
        InterlockedExchange(&s_shutdownRequested, 1);
        PostQuitMessage(0);
        return 0;
    }

    return DefWindowProc(hWnd, msg, wParam, lParam);
}

// ============================================================
// Bot 執行緒（遊戲心跳）
// ============================================================
static DWORD WINAPI BotThread(LPVOID) {
    GameHandle gh{};

    DWORD lastFindLog = 0;
    auto SleepInterruptible = [](DWORD totalMs) -> bool {
        DWORD waited = 0;
        while (g_Running && waited < totalMs) {
            DWORD chunk = (totalMs - waited > 50) ? 50 : (totalMs - waited);
            Sleep(chunk);
            waited += chunk;
        }
        if (!g_Running) { Dbg("[BotThread] g_Running=false, exiting..."); }
        return g_Running;
    };

    while (g_Running) {
        if (!FindGameProcess(&gh)) {
            DWORD now = GetTickCount();
            if (now - lastFindLog > 3000) {
                UIAddLog("[偵測] 找不到 Game.exe，等待中...");
                lastFindLog = now;
            }
            if (!SleepInterruptible(2000)) break;
            continue;
        }

        UIAddLog("[偵測] 已附加遊戲：PID=%u Base=0x%08X HWND=%p",
            gh.pid, gh.baseAddr, gh.hWnd);
        printf("[偵測] 找到遊戲！PID=%lu Base=0x%lX\n",
            gh.pid, gh.baseAddr);

        int clientW = 0;
        int clientH = 0;
        if (GetGameClientSize(&gh, &clientW, &clientH)) {
            UIAddLog("[Detect] Game client=%dx%d", clientW, clientH);
            if (clientW != 1024 || clientH != 768) {
                if (EnsureGameClientSize(&gh, 1024, 768)) {
                    UIAddLog("[Detect] Normalized game client to 1024x768");
                } else {
                    UIAddLog("[Detect] Failed to normalize game client, current=%dx%d",
                        clientW, clientH);
                }
            }
        }

        // 更新全域句柄供 GUI 使用
        SetGameHandle(&gh);

        // BotTick 迴圈（同時輪詢熱鍵）
        while (g_Running && gh.attached && IsGameRunning(&gh)) {
            // F11/F12 現由專屬熱鍵執行緒處理（SetWindowsHookEx）
            BotTick(&gh);
        }

        CloseGameHandle(&gh);
        gh = GameHandle{};
        SetGameHandle(NULL);  // 清除全域句柄
        if (!g_Running) break;
        UIAddLog("[偵測] 遊戲已關閉，重新等待...");
        if (!SleepInterruptible(2000)) break;
    }
    return 0;
}

static bool JoinBotThread(DWORD timeoutMs) {
    if (!s_hBotThread) {
        return true;
    }
    Dbg("[Shutdown] waiting for BotThread...");
    DWORD waitResult = WaitForSingleObject(s_hBotThread, timeoutMs);
    if (waitResult == WAIT_OBJECT_0) {
        CloseHandle(s_hBotThread);
        s_hBotThread = NULL;
        Dbg("[Shutdown] BotThread exited cleanly");
        return true;
    }
    if (waitResult == WAIT_TIMEOUT) {
        Dbg("[Shutdown] BotThread timeout; process will exit without force-killing thread");
    } else {
        Dbgf("[Shutdown] BotThread wait failed: %lu", (unsigned long)GetLastError());
    }
    CloseHandle(s_hBotThread);
    s_hBotThread = NULL;
    return false;
}

// ============================================================
// 設置深色科技風格主題
// ============================================================
void SetupImGuiStyle() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    // 圓角
    style.WindowRounding = 0.0f;  // ✅ 無圓角邊框
    style.FrameRounding = 4.0f;
    style.TabRounding = 0.0f;  // ✅ 標籤無圓角
    style.GrabRounding = 3.0f;
    style.PopupRounding = 4.0f;
    style.ScrollbarRounding = 0.0f;

    // 邊框
    style.WindowBorderSize = 0.0f;  // ✅ 無窗口邊框
    style.ChildBorderSize = 0.0f;   // ✅ 無子窗口邊框
    style.PopupBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;   // ✅ 無框架邊框
    style.TabBorderSize = 0.0f;     // ✅ 無標籤邊框

    // 間距優化 - Tab 分頁可讀性
    style.WindowPadding = ImVec2(0, 0);  // ✅ 無窗口內邊距
    style.FramePadding = ImVec2(4, 3);   // ✅ 稍微增加框架內邊距
    style.ItemSpacing = ImVec2(8, 6);    // ✅ 增加項目間距，提高可讀性
    style.ItemInnerSpacing = ImVec2(4, 4);
    style.TabBarBorderSize = 0.0f;       // ✅ Tab 欄無邊框
    style.TabMinWidthForCloseButton = 0.0f;  // ✅ 不顯示 Tab 關閉按鈕

    // 深色藍紫科技主題（移除所有可見邊框）
    // 背景顏色統一為 RGB(30, 30, 40) = 0.118, 0.118, 0.157
    const ImVec4 uniformBg = ImVec4(0.118f, 0.118f, 0.157f, 1.0f);  // 統一背景色

    colors[ImGuiCol_WindowBg]           = uniformBg;
    colors[ImGuiCol_ChildBg]            = uniformBg;
    colors[ImGuiCol_PopupBg]            = uniformBg;
    colors[ImGuiCol_FrameBg]            = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_FrameBgHovered]     = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_FrameBgActive]      = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_Border]             = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);  // ✅ 無邊框
    colors[ImGuiCol_BorderShadow]       = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);  // ✅ 無陰影
    colors[ImGuiCol_TitleBg]            = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_TitleBgActive]      = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_TitleBgCollapsed]   = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_Tab]                = uniformBg;  // ✅ 統一為背景色
    colors[ImGuiCol_TabHovered]         = ImVec4(0.28f, 0.35f, 0.60f, 0.80f);
    colors[ImGuiCol_TabActive]          = ImVec4(0.20f, 0.25f, 0.48f, 1.00f);
    colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.15f, 0.20f, 0.38f, 1.00f);
    colors[ImGuiCol_Button]             = ImVec4(0.18f, 0.22f, 0.38f, 1.00f);
    colors[ImGuiCol_ButtonHovered]      = ImVec4(0.28f, 0.35f, 0.58f, 1.00f);
    colors[ImGuiCol_ButtonActive]       = ImVec4(0.35f, 0.42f, 0.65f, 1.00f);
    colors[ImGuiCol_Header]             = ImVec4(0.18f, 0.22f, 0.38f, 0.80f);
    colors[ImGuiCol_HeaderHovered]      = ImVec4(0.28f, 0.35f, 0.58f, 0.80f);
    colors[ImGuiCol_HeaderActive]       = ImVec4(0.35f, 0.42f, 0.65f, 1.00f);
    colors[ImGuiCol_SliderGrab]         = ImVec4(0.35f, 0.45f, 0.70f, 1.00f);
    colors[ImGuiCol_SliderGrabActive]   = ImVec4(0.45f, 0.55f, 0.80f, 1.00f);
    colors[ImGuiCol_CheckMark]          = ImVec4(0.45f, 0.60f, 0.90f, 1.00f);
    colors[ImGuiCol_ScrollbarBg]        = ImVec4(0.06f, 0.06f, 0.10f, 0.50f);
    colors[ImGuiCol_ScrollbarGrab]      = ImVec4(0.25f, 0.25f, 0.40f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.35f, 0.35f, 0.55f, 1.00f);
    colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.45f, 0.45f, 0.65f, 1.00f);
    colors[ImGuiCol_Text]               = ImVec4(0.88f, 0.90f, 0.95f, 1.00f);
    colors[ImGuiCol_TextDisabled]       = ImVec4(0.45f, 0.45f, 0.55f, 1.00f);
    colors[ImGuiCol_Separator]          = ImVec4(0.25f, 0.25f, 0.40f, 0.50f);
    colors[ImGuiCol_PlotHistogram]      = ImVec4(0.35f, 0.55f, 0.85f, 1.00f);
}

// ============================================================
// 主程式
// ============================================================
static void Dbg(const char* msg) {
    FILE* fp = NULL;
    char logPath[MAX_PATH];
    GetModuleFileNameA(NULL, logPath, MAX_PATH);
    char* lastSlash = strrchr(logPath, '\\');
    if (lastSlash) *lastSlash = '\0';
    strncat_s(logPath, MAX_PATH, "\\dbg_main.log", _TRUNCATE);
    fopen_s(&fp, logPath, "a");
    if (fp) { fprintf(fp, "%s\n", msg); fclose(fp); }
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD written;
    WriteFile(hCon, msg, (DWORD)strlen(msg), &written, NULL);
    WriteFile(hCon, "\n", 1, &written, NULL);
}

static void Dbgf(const char* fmt, ...) {
    char msg[512] = {0};
    va_list args;
    va_start(args, fmt);
    _vsnprintf_s(msg, sizeof(msg), _TRUNCATE, fmt, args);
    va_end(args);
    Dbg(msg);
}

int main() {
    // 單一實例保護
    if (!AcquireSingleInstance()) {
        printf("[錯誤] JyTrainer 已經在運行中\n");
        MessageBoxW(NULL, L"JyTrainer 已經在運行中", L"單一實例", MB_ICONWARNING | MB_OK);
        return 1;
    }

    // 設定控制台為 UTF-8 編碼（Win7/Win10 通用，解決中文顯示亂碼）
    SetConsoleOutputCP(65001);   // CP_UTF8
    SetConsoleCP(65001);
    setlocale(LC_ALL, ".65001");

    // 檢查命令列參數
    bool hiddenMode = false;
    for (int i = 1; i < __argc; i++) {
        if (!__argv[i]) continue;
        if (_stricmp(__argv[i], "-hidden") == 0 || _stricmp(__argv[i], "-h") == 0) {
            hiddenMode = true;
            continue;
        }
    }

    Dbg("=== 主程式進入 ===");
    {
        wchar_t exePath[MAX_PATH] = {};
        if (GetModuleFileNameW(NULL, exePath, MAX_PATH) > 0) {
            char exePathA[MAX_PATH] = {};
            WideCharToMultiByte(CP_UTF8, 0, exePath, -1, exePathA, MAX_PATH, NULL, NULL);
            printf("[Init] EXE Path: %s\n", exePathA);
            Dbgf("[Init] EXE Path: %s", exePathA);
        }
    }
    ImGui_ImplWin32_EnableDpiAwareness();

    InitBotLogic();
    Dbg("機器人邏輯初始化完成");

    // 偏移策略：只使用內建唯一偏移，不讀取外部檔案
    printf("[Config] Using built-in offsets only...\n");
    bool offsetsLoaded = OffsetConfig::LoadFromFile();
    if (offsetsLoaded) {
        printf("[Config] Offsets loaded from: %s\n", OffsetConfig::GetLoadSource());
    } else {
        printf("[Config] Using built-in defaults only.\n");
    }
    Dbgf("[Config] offset_source=%s version=%lu",
        OffsetConfig::GetLoadSource(),
        (unsigned long)OffsetConfig::GetConfigVersion());
    Dbgf("[Config] GLCharacter=0x%08X MapID=0x%08X PosX=0x%08X PosZ=0x%08X HasTarget=0x%08X",
        OffsetConfig::GLCharacterObj(),
        OffsetConfig::PlayerMapID(),
        OffsetConfig::PlayerPosX(),
        OffsetConfig::PlayerPosZ(),
        OffsetConfig::TargetHasTarget());

    // NT API 記憶體初始化
    if (!InitNtMemoryFunctions()) {
        printf("[警告] NT API 初始化失敗，使用傳統模式\n");
        Dbg("NT API 初始化失敗");
    }
    Dbg("NT API 記憶體初始化完成");

    // 啟動 Bot 執行緒
    printf("[Init] Before CreateThread...\n");
    s_hBotThread = CreateThread(NULL, 0, BotThread, NULL, 0, NULL);
    if (!s_hBotThread) {
        printf("[錯誤] 建立 Bot 執行緒失敗！\n");
        Dbg("建立 Bot 執行緒失敗");
        g_Running = false;
        return 1;
    }
    printf("[啟動] Bot 執行緒已建立\n");
    Dbg("Bot 執行緒已建立");

    // ============================================================
    // 創建 GUI 窗口
    // ============================================================
    // 創建 GUI 窗口 - 完整深色科技風主視窗
    // ============================================================
    printf("[Init] Creating window class...\n");
    WNDCLASSEX wc = {};
    wc.cbSize = sizeof(WNDCLASSEX);
    wc.style = CS_CLASSDC;
    wc.lpfnWndProc = WndProc;
    wc.hInstance = GetModuleHandle(NULL);
    wc.lpszClassName = TEXT("JyTrainerWindow");
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hIcon = (HICON)LoadImage(wc.hInstance, MAKEINTRESOURCE(IDI_APP_ICON),
        IMAGE_ICON, 32, 32, LR_SHARED);
    wc.hIconSm = (HICON)LoadImage(wc.hInstance, MAKEINTRESOURCE(IDI_APP_ICON),
        IMAGE_ICON, 16, 16, LR_SHARED);
    // 深色背景刷，與 ImGui 主題一致
    wc.hbrBackground = CreateSolidBrush(RGB(26, 28, 38));
    RegisterClassEx(&wc);

    printf("[Init] Creating window...\n");
    DWORD dwExStyle = WS_EX_APPWINDOW;
    if (g_alwaysOnTop) dwExStyle |= WS_EX_TOPMOST;

    // 無邊框純 ImGui 窗口 - 完全由 ImGui 控制外觀
    DWORD dwStyle = WS_POPUP | WS_SYSMENU | WS_MINIMIZEBOX;

    g_hWnd = CreateWindowExW(dwExStyle, L"JyTrainerWindow", L"JyTrainer",
        dwStyle,
        CW_USEDEFAULT, CW_USEDEFAULT, WINDOW_WIDTH, WINDOW_HEIGHT,
        NULL, NULL, wc.hInstance, NULL);

    if (!CreateDeviceD3D(g_hWnd)) {
        CleanupDeviceD3D();
        UnregisterClassW(L"JyTrainerWindow", wc.hInstance);
        return 1;
    }

    if (hiddenMode) {
        g_guiVisible = false;
        ShowWindow(g_hWnd, SW_HIDE);
        Dbg("=== 隱藏模式啟動 ===");
    } else {
        g_guiVisible = true;
        ShowWindow(g_hWnd, SW_SHOWDEFAULT);
    }
    UpdateWindow(g_hWnd);

    // ✅ 註冊 trainer 視窗句柄，確保輸入发送到游戏（而非 trainer 本身）
    RegisterTrainerWindow(g_hWnd);

    // 初始化熱鍵系統：必須等 g_hWnd 建立後才能 RegisterHotKey。
    printf("[Init] Before InitHotkeys...\n");
    InitHotkeys();
    printf("[Init] After InitHotkeys\n");

    // 初始化 ImGui
    printf("[Init] Creating ImGui context...\n");
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    // 加載中文字體（加大字體提升清晰度）
    printf("[Init] Loading fonts...\n");
    ImFontConfig fontCfg;
    fontCfg.FontNo = 0;  // TTC 中第一個字體
    fontCfg.OversampleH = 3;  // 水平抗鋸齒
    fontCfg.OversampleV = 3;  // 垂直抗鋸齒
    fontCfg.PixelSnapH = false;

    // 預先獲取字形範圍（避免重複調用）
    static const ImWchar* glyphRanges = io.Fonts->GetGlyphRangesChineseFull();
    printf("[Init] Getting glyph ranges...\n");

    // 字體大小設定（18pt = 24px，更清晰）
    const float fontSize = 18.0f;

    // 嘗試載入微軟正黑體
    ImFont* font = NULL;
    FILE* f = fopen("C:\\Windows\\Fonts\\msjh.ttc", "rb");
    if (f) {
        fclose(f);
        printf("[Init] Loading msjh.ttc (%.0fpt)...\n", fontSize);
        font = io.Fonts->AddFontFromFileTTF(
            "C:\\Windows\\Fonts\\msjh.ttc", fontSize, &fontCfg, glyphRanges);
    }

    // 如果正黑體載入失敗，嘗試細明體
    if (!font) {
        FILE* f2 = fopen("C:\\Windows\\Fonts\\mingliu.ttc", "rb");
        if (f2) { fclose(f2); printf("[Init] Loading mingliu.ttc (%.0fpt)...\n", fontSize); }
        fontCfg.FontNo = 0;
        font = io.Fonts->AddFontFromFileTTF(
            "C:\\Windows\\Fonts\\mingliu.ttc", fontSize, &fontCfg, glyphRanges);
    }

    // 最後 fallback：使用新宋體
    if (!font) {
        FILE* f3 = fopen("C:\\Windows\\Fonts\\simsun.ttc", "rb");
        if (f3) { fclose(f3); printf("[Init] Loading simsun.ttc (%.0fpt)...\n", fontSize); }
        font = io.Fonts->AddFontFromFileTTF(
            "C:\\Windows\\Fonts\\simsun.ttc", fontSize, &fontCfg, glyphRanges);
    }

    if (!font) {
        printf("[警告] 無法載入任何中文字體 (msjh/mingliu/simsun)，中文介面可能顯示方塊！\n");
        // UIAddLog 稍後可用，但此處用 printf 確保
    }
    printf("[Init] Font loading done. Font pointer: %p\n", (void*)font);

    SetupImGuiStyle();

    printf("[Init] Initializing Win32 ImGui...\n");
    ImGui_ImplWin32_Init(g_hWnd);
    printf("[Init] Initializing DX9 ImGui...\n");
    ImGui_ImplDX9_Init(g_pd3dDevice);
    g_imguiReady = true;

    // ✅ 確保 DisplaySize 正確設置
    RECT rect;
    GetClientRect(g_hWnd, &rect);
    io.DisplaySize = ImVec2((float)rect.right, (float)rect.bottom);

    printf("[Init] ImGui initialization complete! DisplaySize=%.0fx%.0f\n", io.DisplaySize.x, io.DisplaySize.y);

    // 消息循環（持續處理消息直到收到 WM_QUIT）
    MSG msg = {};
    bool shutdownRequested = false;
    static DWORD s_lastShutdownCheck = 0;
    while (!shutdownRequested) {
        // 處理消息（帶超時，防止阻擋）
        if (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                Dbg("[Main] Received WM_QUIT, exiting loop");
                shutdownRequested = true;
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

        // 檢查 shutdown 請求（窗口關閉或熱鍵觸發）
        if (s_shutdownRequested) {
            shutdownRequested = true;
            Dbg("[Main] Shutdown requested, ensuring WM_QUIT posted");
            PostQuitMessage(0);
            continue;
        }

        // 如果窗口已銷毀，強制退出
        if (g_hWnd && !IsWindow(g_hWnd)) {
            Dbg("[Main] Window destroyed, forcing exit");
            shutdownRequested = true;
            PostQuitMessage(0);
            continue;
        }

        // 每秒檢查一次 shutdown 狀態
        DWORD now = GetTickCount();
        if (now - s_lastShutdownCheck > 1000) {
            s_lastShutdownCheck = now;
            if (s_shutdownRequested) {
                Dbg("[Main] Periodic check: shutdown requested");
            }
        }

        // GUI 隱藏時跳過渲染，降低 CPU 佔用
        if (!g_guiVisible) {
            Sleep(50);
            continue;
        }

        // 開始 ImGui 幀（每次循環都要更新，確保滑鼠狀態正確）
        ImGui_ImplDX9_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // 渲染主 GUI
        RenderMainGUI();

        // 渲染
        ImGui::EndFrame();

        // 🐛 修復: 增強設備狀態檢查，處理設備丟失和重置
        HRESULT deviceStatus = g_pd3dDevice->TestCooperativeLevel();
        if (deviceStatus == D3DERR_DEVICELOST) {
            // 設備丟失，等待恢復
            Sleep(50);
            continue;
        } else if (deviceStatus == D3DERR_DEVICENOTRESET) {
            // 設備需要重置
            ImGui_ImplDX9_InvalidateDeviceObjects();
            HRESULT resetResult = g_pd3dDevice->Reset(&g_d3dpp);
            if (resetResult == D3D_OK) {
                ImGui_ImplDX9_CreateDeviceObjects();
            } else {
                printf("[警告] Device Reset 失敗: 0x%08lX\n", (unsigned long)resetResult);
                Sleep(50);
                continue;
            }
        }

        g_pd3dDevice->SetRenderState(D3DRS_ZENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
        g_pd3dDevice->SetRenderState(D3DRS_SCISSORTESTENABLE, FALSE);

        // ✅ 確保視口與窗口一致
        RECT rc;
        GetClientRect(g_hWnd, &rc);
        D3DVIEWPORT9 vp = {0, 0, (DWORD)rc.right, (DWORD)rc.bottom, 0.0f, 1.0f};
        g_pd3dDevice->SetViewport(&vp);

        // 深色背景清除
        g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_ARGB(255, 26, 28, 38), 1.0f, 0);

        if (g_pd3dDevice->BeginScene() >= 0) {
            ImGui::Render();
            ImGui_ImplDX9_RenderDrawData(ImGui::GetDrawData());
            g_pd3dDevice->EndScene();
            g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
        }

        Sleep(16);  // ~60 FPS 幀率限制
    }

    Dbg("[Main] Message loop exiting");
    RequestAppShutdown(g_hWnd, "MessageLoopExit");

    // 清理熱鍵執行緒
    ShutdownHotkeys();

    bool botExited = JoinBotThread(5000);

    // 隱藏窗口
    if (g_hWnd && IsWindow(g_hWnd)) {
        ShowWindow(g_hWnd, SW_HIDE);
    }

    // 清理 ImGui
    if (g_imguiReady) {
        g_imguiReady = false;
        ImGui_ImplDX9_Shutdown();
        ImGui_ImplWin32_Shutdown();
        ImGui::DestroyContext();
    }

    // F10 由 WH_KEYBOARD_LL 鉤子處理，無需 UnregisterHotKey
    if (botExited) {
        ShutdownBotLogic();
        CleanupGameProcess();
    } else {
        Dbg("[Shutdown] skipped bot/game cleanup because BotThread is still unwinding");
    }
    CleanupDeviceD3D();
    if (g_hWnd && IsWindow(g_hWnd)) {
        DestroyWindow(g_hWnd);
    }
    UnregisterClassW(L"JyTrainerWindow", wc.hInstance);

    printf("\n[關閉] 正在結束...\n");
    Dbg("=== 主程式結束 ===");
    ReleaseSingleInstance();

    // 確保進程退出
    Dbg("[Main] Calling ExitProcess");
    fflush(stdout);
    ExitProcess(0);
    return 0;  // 不會執行到這裡
}
